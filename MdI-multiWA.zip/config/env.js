'use strict';

module.exports = {

    BYPASS_ANTIBAN:

        process.env.BYPASS_ANTIBAN === 'true'

};