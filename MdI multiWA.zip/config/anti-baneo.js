// config/anti-baneo.js
const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '..', 'data');
const CONFIG_FILE = path.join(DATA_DIR, 'config-antibaneo.json');

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

// Configuración por defecto (se usa si no existe el archivo)
const CONFIG_DEFAULT = {
    HORA_INICIO: 9,
    HORA_FIN: 18,
    MAX_MENSAJES_HORA: 5,
    MAX_MENSAJES_DIA: 40,
    PAUSA_BASE: 120000,   // ms
    PAUSA_MAX: 180000     // ms (informativo, el cálculo real usa ruido aleatorio)
};

// FIX: cargar configuración persistida en disco, o usar default
function cargarConfig() {
    try {
        if (fs.existsSync(CONFIG_FILE)) {
            const guardada = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
            return { ...CONFIG_DEFAULT, ...guardada };
        }
    } catch (e) {
        console.error('❌ Error cargando config-antibaneo.json, usando default:', e.message);
    }
    return { ...CONFIG_DEFAULT };
}

// FIX: guardar configuración nueva en disco
function guardarConfig(nuevaConfig) {
    try {
        const validada = {
            HORA_INICIO: Math.max(0, Math.min(23, parseInt(nuevaConfig.HORA_INICIO) || CONFIG_DEFAULT.HORA_INICIO)),
            HORA_FIN: Math.max(0, Math.min(23, parseInt(nuevaConfig.HORA_FIN) || CONFIG_DEFAULT.HORA_FIN)),
            MAX_MENSAJES_HORA: Math.max(1, parseInt(nuevaConfig.MAX_MENSAJES_HORA) || CONFIG_DEFAULT.MAX_MENSAJES_HORA),
            MAX_MENSAJES_DIA: Math.max(1, parseInt(nuevaConfig.MAX_MENSAJES_DIA) || CONFIG_DEFAULT.MAX_MENSAJES_DIA),
            PAUSA_BASE: Math.max(5000, parseInt(nuevaConfig.PAUSA_BASE) || CONFIG_DEFAULT.PAUSA_BASE),
            PAUSA_MAX: Math.max(5000, parseInt(nuevaConfig.PAUSA_MAX) || CONFIG_DEFAULT.PAUSA_MAX)
        };
        fs.writeFileSync(CONFIG_FILE, JSON.stringify(validada, null, 2), 'utf8');
        // Actualizar el objeto CONFIG en memoria también
        Object.assign(CONFIG, validada);
        console.log('⚙️ Configuración anti-baneo actualizada:', validada);
        return validada;
    } catch (e) {
        console.error('❌ Error guardando config-antibaneo.json:', e.message);
        return null;
    }
}

// CONFIG es un objeto mutable — se actualiza in-place para que las funciones
// que ya tienen una referencia a CONFIG vean los cambios sin reiniciar el servidor
const CONFIG = cargarConfig();

// Almacenar contadores por instanceId
const contadores = new Map();
const contadorLote = new Map();

function obtenerContador(instanceId) {
    if (!contadores.has(instanceId)) {
        contadores.set(instanceId, {
            mensajesHoy: 0,
            mensajesEstaHora: 0,
            ultimaHora: new Date().getHours(),
            ultimoResetDia: new Date().toDateString(),
            ultimoEnvio: 0
        });
    }
    return contadores.get(instanceId);
}

function getMensajesHoy(instanceId) {
    actualizarContadores(instanceId);
    return obtenerContador(instanceId).mensajesHoy;
}

function getMensajesEstaHora(instanceId) {
    actualizarContadores(instanceId);
    return obtenerContador(instanceId).mensajesEstaHora;
}

function incrementarMensajesHoy(instanceId) {
    const c = obtenerContador(instanceId);
    const hoy = new Date().toDateString();
    if (hoy !== c.ultimoResetDia) {
        c.mensajesHoy = 0;
        c.ultimoResetDia = hoy;
    }
    c.mensajesHoy++;
}

function incrementarMensajesHora(instanceId) {
    const c = obtenerContador(instanceId);
    const ahora = new Date().getHours();
    if (ahora !== c.ultimaHora) {
        c.mensajesEstaHora = 0;
        c.ultimaHora = ahora;
    }
    c.mensajesEstaHora++;
}

function esHorarioValido() {
    const hora = new Date().getHours();
    return hora >= CONFIG.HORA_INICIO && hora < CONFIG.HORA_FIN;
}

function actualizarContadores(instanceId) {
    const c = obtenerContador(instanceId);
    const ahora = new Date();
    if (ahora.getHours() !== c.ultimaHora) {
        c.mensajesEstaHora = 0;
        c.ultimaHora = ahora.getHours();
    }
    if (ahora.toDateString() !== c.ultimoResetDia) {
        c.mensajesHoy = 0;
        c.ultimoResetDia = ahora.toDateString();
    }
}

function puedeEnviarMas(instanceId) {
    actualizarContadores(instanceId);
    if (!esHorarioValido()) return false;
    const c = obtenerContador(instanceId);
    return (
        c.mensajesEstaHora < CONFIG.MAX_MENSAJES_HORA &&
        c.mensajesHoy < CONFIG.MAX_MENSAJES_DIA
    );
}

function getPausaAleatoria(indice) {
    let extra = 0;
    if (!contadorLote.has(indice)) contadorLote.set(indice, 0);
    const enviadosLote = contadorLote.get(indice);
    if (enviadosLote >= 3) {
        extra = 60000;
        contadorLote.set(indice, 0);
    } else {
        contadorLote.set(indice, enviadosLote + 1);
    }
    const ruido = Math.random() * 30000;
    return CONFIG.PAUSA_BASE + ruido + extra;
}

async function controlarTasaEnvio(instanceId) {
    while (!puedeEnviarMas(instanceId)) {
        actualizarContadores(instanceId);
        const espera = Math.max(1000, obtenerTiempoRestante(instanceId) * 1000);
        console.log(`⏳ ${obtenerMotivoPausa(instanceId)}. Esperando ${Math.round(espera / 1000)}s...`);
        await new Promise(r => setTimeout(r, espera));
    }
    incrementarMensajesHora(instanceId);
}

function actualizarUltimoEnvio(instanceId) {
    const c = obtenerContador(instanceId);
    c.ultimoEnvio = Date.now();
}

function tiempoRestanteHora(instanceId) {
    const c = obtenerContador(instanceId);
    if (c.mensajesEstaHora < CONFIG.MAX_MENSAJES_HORA) return 0;
    const ahora = new Date();
    const minutosRestantes = 60 - ahora.getMinutes();
    const segundosRestantes = 60 - ahora.getSeconds();
    return (minutosRestantes * 60) + segundosRestantes;
}

function tiempoRestanteDia(instanceId) {
    const c = obtenerContador(instanceId);
    if (c.mensajesHoy < CONFIG.MAX_MENSAJES_DIA) return 0;
    const ahora = new Date();
    const manana = new Date(ahora);
    manana.setDate(manana.getDate() + 1);
    manana.setHours(0, 0, 0, 0);
    return Math.floor((manana - ahora) / 1000);
}

function tiempoRestanteHorario() {
    if (esHorarioValido()) return 0;
    const ahora = new Date();
    let proximoInicio = new Date(ahora);
    proximoInicio.setHours(CONFIG.HORA_INICIO, 0, 0, 0);
    if (ahora.getHours() >= CONFIG.HORA_FIN) {
        proximoInicio.setDate(proximoInicio.getDate() + 1);
    }
    return Math.floor((proximoInicio - ahora) / 1000);
}

function obtenerMotivoPausa(instanceId) {
    if (!esHorarioValido()) return '📅 Fuera de horario laboral (' + CONFIG.HORA_INICIO + '-' + CONFIG.HORA_FIN + ')';
    const c = obtenerContador(instanceId);
    if (c.mensajesEstaHora >= CONFIG.MAX_MENSAJES_HORA) return `⏱️ Límite por hora (${CONFIG.MAX_MENSAJES_HORA} msgs/hora)`;
    if (c.mensajesHoy >= CONFIG.MAX_MENSAJES_DIA) return `📆 Límite diario (${CONFIG.MAX_MENSAJES_DIA} msgs/día)`;
    return '✅ Sin límites';
}

function obtenerTiempoRestante(instanceId) {
    let tiempo = 0;
    if (!esHorarioValido()) tiempo = tiempoRestanteHorario();
    else if (tiempoRestanteHora(instanceId) > 0) tiempo = tiempoRestanteHora(instanceId);
    else if (tiempoRestanteDia(instanceId) > 0) tiempo = tiempoRestanteDia(instanceId);
    return tiempo;
}

function getUserAgent() {
    const agents = [
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    ];
    return agents[Math.floor(Math.random() * agents.length)];
}

function setNumeroActual(numero) { /* no usado */ }
function getNumeroActual() { return null; }

module.exports = {
    CONFIG,
    cargarConfig,
    guardarConfig,
    getMensajesHoy,
    getMensajesEstaHora,
    incrementarMensajesHoy,
    incrementarMensajesHora,
    esHorarioValido,
    puedeEnviarMas,
    getPausaAleatoria,
    controlarTasaEnvio,
    getUserAgent,
    setNumeroActual,
    getNumeroActual,
    tiempoRestanteHora,
    tiempoRestanteDia,
    tiempoRestanteHorario,
    obtenerMotivoPausa,
    obtenerTiempoRestante,
    actualizarUltimoEnvio
};
